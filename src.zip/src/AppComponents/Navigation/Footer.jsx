const Footer = () => {
    return (
        <div style={{height: "130px", backgroundColor: "#282C35"}}>
            <div style={{height: "100%"}} className="container d-flex align-items-center justify-content-start">
                <div className="footer">© 2020 WAKA MEALS. ALL RIGHTS RESERVED. DESIGNED BY <span className="footer1">VALIDPROFITS</span></div>
            </div>
        </div>
    )
}

export default Footer;